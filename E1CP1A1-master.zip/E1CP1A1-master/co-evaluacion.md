# Pauta evaluación de actividad presencial de la clase.

Se pide evaluar bajo esta pauta los ejercicios de un compañero, para ello se accederá al repositorio del compañero y se creará un fork de este, los ejercicios a revisar serán los dictados en esta pauta y deben ser corregidos según la rubrica expuesta.

Los puntajes por ejercicio deben ser anotados en el markdown de la evaluación y enviados al compañero a través de un pull request.

###Ejercicio 1

| 3 | 2 | 1 |
|---|---|---|
|Se corrigió el problema de intercalado de etiquetas y se agregó la estructura del HTML |Se corrigió el problema del intercalado |No se hizo el ejercicio|

###Ejercicio 7

| 3 | 2 | 1 |
|---|---|---|
|Se agregó el título, la codificación y se corrigió la etiqueta p | Se arreglaron 2 de los 3 errores | Se encontró solo 1 o ninguno de los errores.

###Ejericicio 10

| 3 | 2 | 1 |
|---|---|---|
|Se agregó el color bajo la directiva style y se corrigió la codificación |Se agregó el color |No se hizo el ejercicio

###Ejericicio 14

| 3 | 2 | 1 |
|---|---|---|
|Se agregó el protocolo al primer link y se envolvió la segunda imagen en un link a google|se realizó solo una de las dos correcciones| No se hizo el ejercicio.

###Ejercicio 18

| 3 | 2 | 1 |
|---|---|---|
|Se corrigió el error tipográfico en el atributo calor y se agregó el separador ;|se realizó solo una de las dos correcciones| No se hizo el ejercicio.


###Ejercicio 25

| 3 | 2 | 1 |
|---|---|---|
|Se agregaron los estilos width y max-width y se agregaron en el head del HTML| Se agregaron el estilo width y max-width de forma inline | sólo se agrego el width o no se hizo el ejercicio.
